/**
 * 
 */
package com.aaa;

/**
 * @author abc
 *
 */
public interface People {
	
	public abstract String eating();
	public abstract String staying();

}
